#pragma once
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <err.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <ncurses.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>

#define PORT 13080
#define IP "82.65.173.135"
#define BUFFER_SIZE 256
#define _GNU_SOURCE