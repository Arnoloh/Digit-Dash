#include <stdio.h>
#include <err.h>
#include <stdlib.h>
#include "customer.h"

/*int main()
{   
    MainMenu();
    return 0;
}*/
