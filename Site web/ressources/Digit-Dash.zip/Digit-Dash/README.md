# Digit-Dash

Digit-Dash est un jeu à jouer à deux avec vos amis, ou non si vous en avez pas.
Le jeu à failli s'appeler Tiger mais on a préféré Digit-Dash

## Compilage
- `make` à la racine du dossier.
