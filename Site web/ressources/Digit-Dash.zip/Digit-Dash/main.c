#include "game/display/menu/ui.h"

int main()
{
    menu();
    return 0;
}