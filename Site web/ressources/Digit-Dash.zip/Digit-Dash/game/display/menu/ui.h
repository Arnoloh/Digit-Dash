#pragma once

#include "../game.h"
#include "../../../Chat/chat.h"
#include "../../../tools/tools.h"
#include "../help/help.h"

#define NB_BOUTONS 4
extern int req;

void display_name(int largeur, int hauteur);
void display_menu(int largeur, int hauteur);
void menu();