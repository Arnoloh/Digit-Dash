#pragma once

#include <ncurses.h>

void display_little_name_help(WINDOW* frame, int largeur, int hauteur);
void display_help(void);

