#pragma once

#include <ncurses.h>

void display_little_name(WINDOW* frame, int largeur, int hauteur);
void display_win(WINDOW** all_win);
