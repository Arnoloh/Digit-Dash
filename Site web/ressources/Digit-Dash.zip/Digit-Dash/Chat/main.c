#include "chat.h"

int main(void)
{
    u2u();
    return 0;
}
