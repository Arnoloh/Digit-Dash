#include "server.h"

int main(void)
{

    server();
    return 0;

}
